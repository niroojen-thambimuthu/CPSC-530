const zxcvbn = require('zxcvbn');
const util = require('util');
const readline = require('readline');
const fs = require('fs');

// Result containing all passwords
var result = [];


// Read password file
const rl = readline.createInterface({
  input: fs.createReadStream('commonpass.txt'),
  crlfDelay: Infinity
});

rl.on('line', (line) => {
  //console.log(zxcvbn(line));
  result.push(zxcvbn(line));
});

rl.on('close', () => {
  console.log(`Loaded ${result.length} passwords`);
  
  // Write a JSON output
  fs.writeFile('output.js', JSON.stringify(result),  (err) => {
    if (err) throw err;
    console.log('JSON output has been saved!');
  });
  
  // Write a text output
  fs.writeFile('output.txt', util.inspect(result, {showHidden: false, depth: null}),  (err) => {
    if (err) throw err;
    console.log('Text file has been saved!');
  });
  
  // Write score per output
  scores = result.map(r => `${r.password}: ${r.score}`);
  fs.writeFile('scores.txt', scores.join("\n"),  (err) => {
    if (err) throw err;
    console.log('Scores file has been saved!');
  });
});